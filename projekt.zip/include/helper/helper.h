#ifndef HELPER_H
#define HELPER_H

void error_with_exit(const int, const char *);
void str_to_lower(char *);
int max(int, int);
#endif