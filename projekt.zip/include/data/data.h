#ifndef DATA_H
#define DATA_H

int Measurement(int**);
#endif