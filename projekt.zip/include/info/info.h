#ifndef INFO_H
#define INFO_H

void help();
void version();

#endif