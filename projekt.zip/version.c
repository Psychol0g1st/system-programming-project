#include <stdio.h>

int main()
{
    printf("C version: %ld\n", __STDC_VERSION__); // 201710/ C11
    return 0;
}